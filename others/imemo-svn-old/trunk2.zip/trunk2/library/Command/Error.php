<?php
class Command_Error extends Command_Abstract
{
  public function executeCommand()
  {
	return false;
  }

  public function unExecuteCommand()
  {
	return false;
  }

}
