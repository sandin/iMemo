
/* 创建原始数据 */
/*
INSERT INTO lds0019_users VALUE
(NULL,'lds2012@gmail.com','25d55ad283aa400af464c76d713c07ad',1261027980,NULL);
*/
INSERT INTO lds0019_notes_categorys VALUE(null,'Inbox',1261027980);
INSERT INTO lds0019_notes_categorys VALUE(null,'Today',1261027980);
INSERT INTO lds0019_notes_categorys VALUE(null,'Next',1261027980);
INSERT INTO lds0019_notes_categorys VALUE(null,'Maybe',1261027980);
INSERT INTO lds0019_notes_categorys VALUE(null,'Projects',1261027980);
INSERT INTO lds0019_notes_categorys VALUE(null,'Areas',1261027980);
INSERT INTO lds0019_notes_categorys VALUE(null,'uncategory',1261027980);
INSERT INTO lds0019_notes_categorys VALUE(null,'uncategory',1261027980);
INSERT INTO lds0019_notes_categorys VALUE(null,'uncategory',1261027980);
INSERT INTO lds0019_notes_categorys VALUE(null,'uncategory',1261027980);
INSERT INTO lds0019_notes_categorys VALUE(null,'uncategory',1261027980);

INSERT INTO lds0019_users_link_categorys VALUE(null,1,1);
INSERT INTO lds0019_users_link_categorys VALUE(null,1,2);
INSERT INTO lds0019_users_link_categorys VALUE(null,1,3);
INSERT INTO lds0019_users_link_categorys VALUE(null,1,4);
INSERT INTO lds0019_users_link_categorys VALUE(null,1,5);
INSERT INTO lds0019_users_link_categorys VALUE(null,1,6);

