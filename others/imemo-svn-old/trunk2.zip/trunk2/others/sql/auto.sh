#!/bin/sh

cat 0019*.sql > all.sql;

mysql -u lds -p < all.sql;
