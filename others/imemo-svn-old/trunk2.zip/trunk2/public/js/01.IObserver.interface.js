
/** 
 * interface IObserver
 * 
 * @return 
 */
function IObserver(){}

IObserver.prototype.update = function(sender,msg){} 

