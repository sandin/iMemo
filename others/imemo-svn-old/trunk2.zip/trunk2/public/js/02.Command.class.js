
/** 
 * class Command
 * Command的超类
 * 
 * @param params
 * 
 * @return 
 */
function Command(params)
{
  this.params = params || {};
}

Command.prototype.setParams = function(params)
{
  this.params = params;
}


