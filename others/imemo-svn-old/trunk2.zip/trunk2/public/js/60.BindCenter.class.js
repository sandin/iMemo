
/** 
 * class BindCenter implements ISubject
 * 
 * @return 
 */
function BindCenter()
{
  ISubject.call(this);
} 

BindCenter.prototype = new ISubject(); 

